guesstimate.contarmination <-
function(logR, region.idx=NULL) {
	return(guesstimate.contamination(logR, region.idx))
}

