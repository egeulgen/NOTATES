strip.chr.name <-
function(ls) {
	data(chr.hash)
	chr.hash[as.character(ls),2]
}

